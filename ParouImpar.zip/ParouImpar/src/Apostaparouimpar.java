import java.util.Scanner;
import java.util.Random;

public class Apostaparouimpar {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        Random random = new Random();

        System.out.println("Bem-vindo ao jogo de Aposta em Par ou Ímpar!");
        System.out.print("Escolha (1) Par ou (2) Ímpar: ");
        int escolhaUsuario = input.nextInt();

        if (escolhaUsuario != 1 && escolhaUsuario != 2) {
            System.out.println("Escolha inválida. Por favor, escolha 1 para Par ou 2 para Ímpar.");
            return;
        }

        System.out.print("Digite sua aposta: ");
        int apostaUsuario = input.nextInt();

        int numeroAleatorio = random.nextInt(101); // Gera um número aleatório entre 0 e 100.

        System.out.println("Número gerado: " + numeroAleatorio);

        int soma = apostaUsuario + numeroAleatorio;
        boolean ehPar = soma % 2 == 0;

        System.out.println("A soma é " + soma + " (" + (ehPar ? "Par" : "Ímpar") + ").");

        if ((escolhaUsuario == 1 && ehPar) || (escolhaUsuario == 2 && !ehPar)) {
            System.out.println("Você ganhou!");
        } else {
            System.out.println("Você perdeu!");
        }

        input.close();
    }
}

