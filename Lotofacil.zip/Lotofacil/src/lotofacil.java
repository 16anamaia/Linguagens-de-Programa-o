import java.util.Scanner;
import java.util.Random;

public class lotofacil {
    public static void main(String[] args){
        Scanner input = new Scanner(System.in);
        Random random = new Random();
        int opcao;
        input.close();

        do {
            System.out.println("Menu da loteria");
            System.out.println("1. Fazer uma aposta");
            System.out.println("2. Ver resultado da ultima aposta");
            System.out.println("0. Sair");
            System.out.println("Escolha uma opção: ");

        } while (opcao = 0);


    }

}
